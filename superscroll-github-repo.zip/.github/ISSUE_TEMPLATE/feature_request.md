---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

**What would you like SuperScroll to do?**

**What problem does it solve? Which site or situation?**

**Anything you've tried instead?**
