---
name: Bug report
about: SuperScroll stopped early, never stopped, or missed a button
labels: bug
---

**What happened?**

**What did you expect?**

**Page URL** (if public):

**Browser and version** (e.g. Floorp 12, Firefox 140, Chrome 130):

**SuperScroll version:**

**Settings changed from default?**

**For an undetected button:** right-click it → Inspect → paste its HTML here:

```html

```
